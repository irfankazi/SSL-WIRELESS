<?php
function getTextBetweenTags($string, $tagname) {
        $pattern = "/<$tagname ?.*>(.*)<\/$tagname>/";
        preg_match($pattern, $string, $matches);
        return $matches[1];
}

function SaveFile($filename, $contents) {
	try{
		$handle = fopen($filename, 'a');
		if($handle) {
			fputs($handle, $contents."\r\n");
			fclose($handle);
			return true;
		} else {
			return false;
		}
	}catch(exception $ex){
		return false;
	}
}

function CreateLogs($initials, $log, $category="SERVICE", $filename="") {
	//echo $log . "\r\n";
	# DB LOGS

	if($category=="") {
		$category = "unknown";
	}
	ini_set("date.timezone","Asia/Dhaka");
	$webroot=getcwd();
	$abs_path = "/var/www/logs";

	try {
		$mdir = date("Ymd");
		$subdir = $initials;
		$structure = "$abs_path/$category/$mdir/$subdir/";
		if(is_dir($structure)) {
			$time = date("Y-m-d-H");
			if($filename=="" || $filename==null)
				$filename=$initials."_".$time.".txt";
			$Log_File = $structure.$filename;
			$now = date("Y-m-d H:i:s");
			return SaveFile($Log_File, $now." - ".$log);
		} else if (mkdir($structure, 0777, true)) {
			chmod("$abs_path/$category/$mdir/", 0777);
			chmod("$abs_path/$category/$mdir/$subdir/", 0777);
			$time = date("Y-m-d-H");
			if($filename=="" || $filename==null)
				$filename=$initials."_".$time.".txt";
			$Log_File = $structure.$filename;
			$now = date("Y-m-d H:i:s");
			return SaveFile($Log_File, $now." - ".$log);
		} else {
			return false;
		}
	}catch(exception $ex){
		return false;
	}
}

function _ssllogs($data=''){
	//$log_file = 'log.txt';
	CreateLogs("LOGDATA", $data);
	//file_put_contents($log_file, $data);

}

# MOBILE NUMBER CHECK
function CheckNumber($msisdn) {
        $regexp = "/^(88|)01[1,5,6,7,8,9]{1}[0-9]{8}$/";
        if(preg_match($regexp, $msisdn)) return true;
        return false;
}

function _test_mobile_no($mobile_no = ""){
        $mobile_no = trim($mobile_no);

        if(strlen($mobile_no)=='11') {
                if(CheckNumber($mobile_no)) {           # CHECK WHETHER ALL BANGLADESHI NUMBER  
                        return "88" . $mobile_no;

                } else return false;
        } else if(strlen($mobile_no)>'11') {    # ALREADYND ADDED 88 OR ABROAD SMS 
                if(is_numeric($mobile_no)) {            # CHECK ALL ARE NUMBER
                        return $mobile_no;

                } else return false;

        } else {
                return false;   # ELSE INVALID NUMBER
        }
}

