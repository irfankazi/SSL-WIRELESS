<?php

$special[0]="‘’";
$normal[0]='"';
$special[1]="“";
$normal[1]='"';
$special[2]="”";
$normal[2]='"';
$special[3]=":";
$normal[3]=":";
$special[4]=";";
$normal[4]=";";
$special[5]="~";
$normal[5]="~";
$special[6]="`";
$normal[6]="'";
$special[7]="!";
$normal[7]="!";
$special[8]="@";
$normal[8]="@";
$special[9]="#";
$normal[9]="#";
$special[10]="$";
$normal[10]="$";
$special[11]="%";
$normal[11]="%";
$special[12]="^";
$normal[12]="^";
$special[13]="&";
$normal[13]="&";
$special[14]="*";
$normal[14]="*";
$special[15]="(";
$normal[15]="(";
$special[16]=")";
$normal[16]=")";
$special[17]="’";
$normal[17]="'";
$special[18]="–";
$normal[18]="-";
$special[19]="‘";
$normal[19]="'";
$special[20]="‘";
$normal[20]="'";


//$text="a“b”c;d’e:f`g-e-h%j";
//echo "Original text:".$text;
//echo "<br /> After replace:".str_replace($special,$normal,$text);

?>