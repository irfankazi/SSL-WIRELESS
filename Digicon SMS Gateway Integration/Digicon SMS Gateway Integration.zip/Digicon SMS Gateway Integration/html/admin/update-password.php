<?php
require 'initapp.php';
require ("views/$theme/update-password.tpl.php");
?>